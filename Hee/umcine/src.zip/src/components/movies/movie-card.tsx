import { Link } from "@tanstack/react-router";
import { useFavorites, useToggleFavorite } from "../../hooks/use-favorites";
import type { Movie } from "../../types/movie";

type MovieCardProps = {
  movie: Movie;
};

const bookmarkIcon = "/icons/movie-icons/movie-icons/bookmark.svg";
const bookmarkOutlineIcon = "/icons/movie-icons/movie-icons/bookmark-outline.svg";

export default function MovieCard({ movie }: MovieCardProps) {
  const posterUrl = movie.posterPath;
  const favoritesQuery = useFavorites();
  const toggleFavorite = useToggleFavorite();
  const isBookmarked = favoritesQuery.data?.includes(movie.id) ?? false;

  return (
    <article>
      <div className="relative aspect-[205/232] overflow-hidden rounded-[8px]">
        <Link
          to="/movies/$movieId"
          params={{ movieId: String(movie.id) }}
          className="block h-full"
        >
          {posterUrl ? (
            <img src={posterUrl} alt={`${movie.title} 포스터`} className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full items-center justify-center bg-[#E8EBEF] text-xs text-[#8A929E]">
              포스터 없음
            </div>
          )}
        </Link>
        <button
          type="button"
          onClick={() =>
            toggleFavorite.mutate({ movieId: movie.id, isFavorite: isBookmarked })
          }
          disabled={toggleFavorite.isPending}
          aria-label={`${movie.title} 북마크 ${isBookmarked ? "해제" : "추가"}`}
          aria-pressed={isBookmarked}
          className={`absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-[6px] border ${
            isBookmarked ? "border-[#2F6FED] bg-[#2F6FED]" : "border-white bg-black/60"
          }`}
        >
          <img src={isBookmarked ? bookmarkIcon : bookmarkOutlineIcon} alt="" className="h-[17px] w-[17px] invert" />
        </button>
      </div>
      <Link to="/movies/$movieId" params={{ movieId: String(movie.id) }} className="block">
        <h2 className="mt-2 text-[12px] font-semibold text-[#191D23]">{movie.title}</h2>
      </Link>
      <p className="mt-[2px] text-[11px] text-[#9CA3AF]">
        {movie.releaseDate || "개봉일 정보 없음"}
      </p>
    </article>
  );
}
